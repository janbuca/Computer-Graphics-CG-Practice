# snake-game
self made snake game using c++ and graphics.h
