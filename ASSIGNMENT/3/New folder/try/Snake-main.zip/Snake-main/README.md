# Snake
Basic Snake Game Using Graphics.h In C++
 

I Used DevC++ 4.9.9.2 and MingW32 To Run This


