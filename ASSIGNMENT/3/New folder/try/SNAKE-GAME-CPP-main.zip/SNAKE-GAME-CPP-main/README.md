# SNAKE-GRAPHICS_H
 Snake Game in C++
 Using **graphics.h** header

## Coded by
 *Harshit Sharma*

## Screenshots
![ScreenShot 1](https://github.com/harshit-sharma-gits/SNAKE-GRAPHICS_H/blob/main/ScreenShots/ss1.PNG)
![ScreenShot 1](https://github.com/harshit-sharma-gits/SNAKE-GRAPHICS_H/blob/main/ScreenShots/ss2.PNG)

## Video on YouTube
 *https://www.youtube.com/watch?v=F0-Y1YZ3TEU&list=PLMclp-q8OPhnut08fQIREEpjND7ySy0Q1&index=2*
